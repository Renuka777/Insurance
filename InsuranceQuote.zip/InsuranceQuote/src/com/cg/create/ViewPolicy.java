package com.cg.create;

import java.util.List;

import com.cg.beans.Policy;
import com.cg.exception.UserCustomException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;

public class ViewPolicy {

	InsuranceService service=new InsuranceServiceImpl();
	public List<Policy> viewPolicyDetails() throws UserCustomException{
		
		List<Policy> list=null;
		try {
			list=service.viewPolicyDetails();
		} catch (UserCustomException e) {
			System.err.println(e.getMessage());
		}
		
		return list;
		
	}
	public Policy getPolicy(String userName)throws UserCustomException {
		
		return service.getPolicy(userName);
	}

}
