package com.cg.create;

import java.util.List;

import com.cg.beans.ReportGeneration;
import com.cg.exception.UserCustomException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;

public class GenerateReport {

	InsuranceService insuranceService= new InsuranceServiceImpl();

	public List<ReportGeneration> generateReport(int accountNumber1) throws UserCustomException{
		return insuranceService.generateReport(accountNumber1);
		
	}
}
