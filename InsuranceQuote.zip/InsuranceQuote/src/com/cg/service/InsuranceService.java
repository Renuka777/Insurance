package com.cg.service;

import java.util.List;

import com.cg.beans.Accounts;
import com.cg.beans.Policy;
import com.cg.beans.PolicyDetails;
import com.cg.beans.ReportGeneration;
import com.cg.beans.UserRole;
import com.cg.exception.UserCustomException;

public interface InsuranceService {

	String validUser(UserRole role) throws UserCustomException;

	int createAccount(Accounts accounts) throws UserCustomException;

	boolean validFields(Accounts accounts) throws UserCustomException;

	boolean getUserName(String userName) throws UserCustomException;

	boolean checkUserName(String userName) throws UserCustomException;

	boolean checkPassword(String password) throws UserCustomException;

	boolean checkUserRole(String userRole) throws UserCustomException;

	int addProfile(UserRole role) throws UserCustomException;

	int createPolicy(int accountNumber) throws UserCustomException;

	boolean validAccountNumber(int accountNumber) throws UserCustomException;

	boolean existAccount(int accountNumber) throws UserCustomException;

	String getBuisnessSegment(int accountNumber) throws UserCustomException;

	String getBuisnessSegmentId(String businessSegment) throws UserCustomException;

	List<String> getQuestions(String buisnessSegId) throws UserCustomException;

	List<String> getAnswer(String string) throws UserCustomException;

	int getWeightage(String string, String string2) throws UserCustomException;

	int insertPolicy(Policy policy)throws UserCustomException;

	String getQuesId(String string) throws UserCustomException;

	List<String> getQuestionId(String buisnessSegId) throws UserCustomException;

	void insertPolicyDetails(PolicyDetails policyDetails) throws UserCustomException;

	List<Policy> viewPolicyDetails() throws UserCustomException;

	List<ReportGeneration> generateReport(int accountNumber1) throws UserCustomException;

	Policy getPolicy(String userName) throws UserCustomException;



}
