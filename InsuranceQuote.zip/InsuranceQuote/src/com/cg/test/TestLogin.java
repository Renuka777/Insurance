/*
 * 
 */
package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author gauramal
 *
 */
public class TestLogin {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
